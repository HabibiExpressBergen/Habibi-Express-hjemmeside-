
const RATES = { callout:690, hourly_van2:1290, hourly_extra_mover:390, heavy_item_minutes:20 };
function minutesToHours(min){ return Math.max(0, Number(min||0))/60; }
function formatNOK(n){ try { return new Intl.NumberFormat('no-NO',{style:'currency',currency:'NOK'}).format(n);}catch(e){return n.toFixed(0)+' kr';}}
function estimatePrice(){
  const driveMin = Number(document.getElementById('driveMin')?.value||0);
  const loadMin  = Number(document.getElementById('loadMin')?.value||120);
  const extras   = Number(document.getElementById('heavyItems')?.value||0);
  const extraMov = Number(document.getElementById('extraMoverHours')?.value||0);
  const extraMinutes = extras * RATES.heavy_item_minutes;
  const totalHours = minutesToHours(driveMin + loadMin + extraMinutes);
  const base = RATES.callout + (totalHours * RATES.hourly_van2);
  const extra = extraMov * RATES.hourly_extra_mover;
  const total = Math.round(base + extra);
  const el = document.getElementById('estimateTotal'); if(el) el.textContent = formatNOK(total);
}
document.addEventListener('input',(e)=>{ if(['driveMin','loadMin','heavyItems','extraMoverHours'].includes(e.target.id)){ estimatePrice(); }});
document.addEventListener('DOMContentLoaded', estimatePrice);
